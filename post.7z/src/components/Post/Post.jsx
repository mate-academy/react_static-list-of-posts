import React from 'react';
import PropTypes from 'prop-types';
import { User } from '../User';
import { CommentList } from '../CommentList';

export const Post = ({ title, body, userByPost, commentsByPost }) => (
  <div>
    <h2>{title}</h2>
    <div>{body}</div>
    <User user={userByPost} />
    <CommentList list={commentsByPost} />
  </div>
);

Post.propTypes = {
  title: PropTypes.string.isRequired,
  body: PropTypes.string.isRequired,
  userByPost: PropTypes.shape({
    name: PropTypes.string.isRequired,
  }).isRequired,
  commentsByPost: PropTypes.arrayOf(PropTypes.shape({
    body: PropTypes.string.isRequired,
  })).isRequired,
};
